
# Metodický převodník – výběrová řízení (prototype)

Jednoduchý online nástroj: nahrajete metodický pokyn (+ přílohy jako ZIP), nástroj vrátí **DOCX**, **PNG schéma** a (volitelně) **MP3**.
Navrženo pro personální útvary (bez anglicismů).

## Lokální spuštění

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
# Otevřete http://localhost:8000
```

## Docker

```bash
docker build -t metodika-tool .
docker run -p 8000:8000 --env OPENAI_API_KEY=sk-... metodika-tool
```

## Nasazení (Azure doporučeno)
- **App Service** nebo **Container Apps**.
- Pro soukromí zapněte „data are not used for training“ v Azure OpenAI.
- Proměnné prostředí:
  - `AZURE_OPENAI_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT` **nebo** `OPENAI_API_KEY`
  - (volitelně) `AZURE_SPEECH_KEY`, `AZURE_SPEECH_REGION`, `AZURE_SPEECH_VOICE=cs-CZ-AntoninNeural`

## Jak to funguje
1. Načte text z PDF/DOCX (pdfminer.six, python-docx).
2. Vytvoří prompt pro LLM (OpenAI/Azure OpenAI) -> „plain language“ výstup.
3. Vygeneruje DOCX, PNG a (pokud máte Azure Speech klíč) MP3.
4. Vše vrátí ke stažení.

> Pro přesné citace článků a linky na P1–P23 upravte prompt v `app/utils/generate.py`.
